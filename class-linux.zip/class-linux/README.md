# class-linux

Dear Reader,

This is a repo for a linux course by Gabriel Solomon. The purpose of this repo is to supply basic, but functional ubuntu environment for students. All other course materials are distribtued directly via Canvas.

-Gabriel Solomon, @jeromesolomon
